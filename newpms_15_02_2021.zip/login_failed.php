

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="icon" href="hnet.com-image.ico" type="image/x-icon" >
		<!-- bootstrap css and js -->
		<link rel="stylesheet" href="asset/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
		<script src="asset/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
		<!-- bootstrap jquery and proper.js -->
		<script src="asset/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
		<script src="asset/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
		
		<!-- google fonts -->
		<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="asset/css2.css" rel="stylesheet">
		<!-- JQUERY FROM GOOGLE API -->
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>

    <style>
/* _navbar.scss:184 */


/* _navbar.scss:228 */
$navbar-light-color
$navbar-light-toggler-border-color

/* _navbar.scss:280 */
$navbar-dark-color
$navbar-dark-toggler-border-color
    	
    	/* _navbar.scss:184 */
.navbar-toggler {
  display: none;
}

/* _navbar.scss:228 */
.navbar-toggler {
  color: $navbar-light-color;
  border-color: $navbar-light-toggler-border-color;
}

/* _navbar.scss:280 */
.navbar-toggler {
  color: $navbar-dark-color;
  border-color: $navbar-dark-toggler-border-color;
}
    </style>
	
	</head>
	<body>
<h1 >Your Login Name or Password is Invalid</h1>
		<br/>
	<p>Click here to <a href='index.php'>Login</a> again</p>
</body>
</html>